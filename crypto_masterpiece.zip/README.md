Crypto Masterpiece - Full stack crypto web app
=============================================
This archive contains a complete FastAPI + Docker + Postgres + Redis + Nginx stack,
with WebSockets, JWT auth, Binance integration, and frontend files.

Files of interest:
- docker-compose.yml
- Dockerfile
- .env.example
- app/ (backend code)
- static/ (frontend assets)
- templates/index.html

How to run (basic):
1. Copy .env.example to .env and fill values.
2. docker compose up -d --build
3. Visit http://localhost:8000 (or configure nginx and SSL)

Mobile development: use GitHub Codespaces or Working Copy + SSH to manage and deploy from iPhone.
