import redis, os, json, time
REDIS_HOST = os.getenv('REDIS_HOST', 'redis')
client = redis.Redis(host=REDIS_HOST, port=6379, db=0, decode_responses=True)

def cache_set(key, value, ttl=10):
    try:
        client.set(key, json.dumps(value), ex=ttl)
    except Exception:
        pass

def cache_get(key):
    try:
        v = client.get(key)
        return json.loads(v) if v else None
    except Exception:
        return None
