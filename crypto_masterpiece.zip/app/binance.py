import time
import hmac
import hashlib
import aiohttp
import asyncio
from urllib.parse import urlencode
from app.cache import cache_get, cache_set

BINANCE = "https://api.binance.com"

async def safe_get(url, params=None, headers=None, retries=3):
    params = params or {}
    headers = headers or {}
    backoff = 0.5
    for attempt in range(retries):
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, params=params, headers=headers, timeout=10) as res:
                    if res.status == 200:
                        return await res.json()
                    if res.status == 429:
                        ra = res.headers.get('Retry-After')
                        wait = float(ra) if ra else backoff * (2 ** attempt)
                        await asyncio.sleep(wait)
                        continue
                    if 500 <= res.status < 600:
                        await asyncio.sleep(backoff * (2 ** attempt))
                        continue
                    text = await res.text()
                    raise RuntimeError(f'Status {res.status}: {text}')
        except Exception:
            if attempt == retries - 1:
                raise
            await asyncio.sleep(backoff * (2 ** attempt))

async def binance_public_get(path, params=None):
    return await safe_get(BINANCE + path, params=params)

async def binance_signed_get(path, api_key, api_secret, params=None):
    params = params or {}
    params['timestamp'] = int(time.time() * 1000)
    query = urlencode(params)
    signature = hmac.new(api_secret.encode(), query.encode(), hashlib.sha256).hexdigest()
    params['signature'] = signature
    headers = {'X-MBX-APIKEY': api_key}
    return await safe_get(BINANCE + path, params=params, headers=headers)

async def get_price_usd(asset):
    asset = asset.upper()
    cached = cache_get(f'price:{asset}')
    if cached:
        return cached
    # Try direct
    try:
        pair = f'{asset}USDT'
        j = await binance_public_get('/api/v3/ticker/price', {'symbol': pair})
        price = float(j['price'])
        cache_set(f'price:{asset}', price, ttl=8)
        return price
    except Exception:
        pass
    # Fallback via BTC
    try:
        p1 = await binance_public_get('/api/v3/ticker/price', {'symbol': f'{asset}BTC'})
        btc = await binance_public_get('/api/v3/ticker/price', {'symbol': 'BTCUSDT'})
        price = float(p1['price']) * float(btc['price'])
        cache_set(f'price:{asset}', price, ttl=8)
        return price
    except Exception as e:
        raise RuntimeError(f'Cannot price {asset}: {e}')
