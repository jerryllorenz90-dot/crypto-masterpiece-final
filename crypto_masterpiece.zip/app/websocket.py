import aiohttp, asyncio, json
from fastapi import WebSocket, WebSocketDisconnect

connections = set()

async def binance_ws(symbol: str, callback):
    url = f"wss://stream.binance.com:9443/ws/{symbol.lower()}@trade"
    async with aiohttp.ClientSession() as session:
        async with session.ws_connect(url) as ws:
            async for msg in ws:
                if msg.type == aiohttp.WSMsgType.TEXT:
                    data = json.loads(msg.data)
                    await callback(data)

async def price_stream(ws: WebSocket, symbol: str):
    await ws.accept()
    connections.add(ws)
    async def push(data):
        price = float(data.get('p', 0))
        for c in list(connections):
            try:
                await c.send_json({'price': price})
            except:
                connections.remove(c)
    try:
        await binance_ws(symbol, push)
    except WebSocketDisconnect:
        connections.remove(ws)
    except Exception:
        try:
            await ws.close()
        except:
            pass
