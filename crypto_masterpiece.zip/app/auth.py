import os, bcrypt, jwt, datetime
from fastapi import Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from app.database import SessionLocal
from app.models import User

SECRET = os.getenv('JWT_SECRET', 'change_this')
oauth2 = OAuth2PasswordBearer(tokenUrl='token')

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def create_token(user_id: int):
    payload = {'user_id': user_id, 'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=12)}
    return jwt.encode(payload, SECRET, algorithm='HS256')

def verify_password(plain: str, hashed: str):
    return bcrypt.checkpw(plain.encode(), hashed.encode())

def current_user(token: str = Depends(oauth2), db: Session = Depends(get_db)):
    try:
        data = jwt.decode(token, SECRET, algorithms=['HS256'])
    except Exception:
        raise HTTPException(status_code=401, detail='Invalid token')
    user = db.query(User).filter(User.id == data.get('user_id')).first()
    if not user:
        raise HTTPException(status_code=401, detail='User not found')
    return user
