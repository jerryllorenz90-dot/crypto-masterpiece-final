from app.database import SessionLocal
from app.models import Portfolio
from app.binance import get_price_usd
from app.cache import cache_get, cache_set
from sqlalchemy.orm import Session

async def get_portfolio_value(user_id: int):
    key = f'portfolio:{user_id}'
    cached = cache_get(key)
    if cached:
        return cached
    db: Session = SessionLocal()
    try:
        rows = db.query(Portfolio).filter(Portfolio.user_id == user_id).all()
        total = 0.0
        details = []
        for r in rows:
            price = await get_price_usd(r.asset)
            value = price * r.amount
            details.append({'asset': r.asset, 'amount': r.amount, 'price': price, 'value': value})
            total += value
        result = {'total_usd': round(total, 2), 'details': details}
        cache_set(key, result, ttl=10)
        return result
    finally:
        db.close()

async def update_user_asset(user_id: int, asset: str, amount: float):
    db = SessionLocal()
    try:
        asset = asset.upper()
        row = db.query(Portfolio).filter(Portfolio.user_id == user_id, Portfolio.asset == asset).first()
        if row:
            row.amount = amount
        else:
            row = Portfolio(user_id=user_id, asset=asset, amount=amount)
            db.add(row)
        db.commit()
    finally:
        db.close()
    return True
