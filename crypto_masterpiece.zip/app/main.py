import os
import time
from fastapi import FastAPI, Depends, HTTPException, WebSocket
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from dotenv import load_dotenv
from app.rate_limit import RateLimiter
from app.database import Base, engine
from app.auth import get_db, current_user
from app.portfolio import get_portfolio_value, update_user_asset
from app.websocket import price_stream

load_dotenv()

app = FastAPI(title="Crypto Masterpiece")
app.mount("/static", StaticFiles(directory="static"), name="static")

# Create database tables if missing (simple convenience)
Base.metadata.create_all(bind=engine)

app.add_middleware(RateLimiter)

@app.get('/', response_class=HTMLResponse)
async def index():
    with open('templates/index.html', 'r', encoding='utf-8') as f:
        return f.read()

@app.get('/api/portfolio')
async def portfolio(user=Depends(current_user)):
    return await get_portfolio_value(user.id)

@app.post('/api/portfolio')
async def update_portfolio(asset: str, amount: float, user=Depends(current_user)):
    await update_user_asset(user.id, asset, amount)
    return {"status": "ok"}

@app.websocket('/ws/price/{symbol}')
async def ws_price(ws: WebSocket, symbol: str):
    await price_stream(ws, symbol)
