from fastapi import Request, HTTPException
from starlette.middleware.base import BaseHTTPMiddleware
import time

_visits = {}

class RateLimiter(BaseHTTPMiddleware):
    def __init__(self, app, limit: int = 120):
        super().__init__(app)
        self.limit = limit

    async def dispatch(self, request: Request, call_next):
        ip = request.client.host if request.client else 'anon'
        now = time.time()
        arr = _visits.get(ip, [])
        arr = [t for t in arr if now - t < 60]
        if len(arr) >= self.limit:
            raise HTTPException(status_code=429, detail='Rate limit exceeded')
        arr.append(now)
        _visits[ip] = arr
        return await call_next(request)
