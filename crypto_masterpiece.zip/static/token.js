const TOKENS = [{symbol:'BTCUSDT',name:'Bitcoin'},{symbol:'ETHUSDT',name:'Ethereum'},{symbol:'BNBUSDT',name:'BNB'}];

async function loadTokens(){
  const container = document.getElementById('tokens');
  TOKENS.forEach(t=>{
    const card = document.createElement('div'); card.className='token-card';
    card.innerHTML = `<div class="token-meta"><div><div class="token-name">${t.name}</div><div class="token-symbol">${t.symbol}</div></div><div class="token-price" id="price-${t.symbol}">--</div></div><canvas id="chart-${t.symbol}" height="70"></canvas>`;
    container.appendChild(card);
    loadPrice(t.symbol); loadChart(t.symbol); livePrice(t.symbol);
  });
}

async function loadPrice(symbol){
  try{
    const r = await fetch(`https://api.binance.com/api/v3/ticker/price?symbol=${symbol}`);
    const j = await r.json();
    document.getElementById(`price-${symbol}`).textContent = parseFloat(j.price).toFixed(2);
  }catch(e){}
}

async function loadChart(symbol){
  try{
    const r = await fetch(`/api/price-history?symbol=${symbol}&interval=1m&limit=60`);
    const j = await r.json();
    const data = j.data || [];
    new Chart(document.getElementById(`chart-${symbol}`), {type:'line',data:{labels:data.map(d=>new Date(d[0]).toLocaleTimeString()),datasets:[{data:data.map(d=>d[1]),fill:true,tension:0.3,pointRadius:0}]},options:{plugins:{legend:{display:false},tooltip:{enabled:false}},scales:{x:{display:false},y:{display:false}},responsive:true,animation:false}});
  }catch(e){}
}

function livePrice(symbol){
  try{
    const protocol = location.protocol === 'https:' ? 'wss' : 'ws';
    const ws = new WebSocket(`${protocol}://${location.host}/ws/price/${symbol}`);
    ws.onmessage = (ev)=>{ const data = JSON.parse(ev.data); const el = document.getElementById(`price-${symbol}`); if(el && data.price) el.textContent = parseFloat(data.price).toFixed(2); };
  }catch(e){}
}

loadTokens();
(function loadWidget(){ if(document.getElementById('tv-script')) return; const s=document.createElement('script'); s.id='tv-script'; s.src='https://s3.tradingview.com/tv.js'; s.onload=()=>{ if(window.TradingView){ new window.TradingView.widget({container_id:'tradingview',symbol:'BINANCE:BTCUSDT',interval:'60',theme:'dark',style:'1',locale:'en',height:'100%',width:'100%',allow_symbol_change:true}); }}; document.body.appendChild(s); })();
